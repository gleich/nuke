![Title Example](title.gif)

# nuke

![Go Build](https://github.com/Matt-Gleich/nuke/workflows/Go%20Build/badge.svg) ![Go Format](https://github.com/Matt-Gleich/nuke/workflows/Go%20Format/badge.svg)

☢️ Force quit all applications with one terminal command.

## 🚀 Install

Simply run `brew tap Matt-Gleich/homebrew-taps` and then `brew install nuke`

## 🏃 Running

Just run `nuke` and answer the one question to confirm
